﻿namespace BlazorShared.Models
{
    public class EditCatalogItemResult
    {
        public CatalogItem CatalogItem { get; set; } = new CatalogItem();
    }
}
